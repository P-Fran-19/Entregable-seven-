#!/bin/bash

if [[ "$1" == "-help" || "$1" == "--help" ]]; then
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

origen="$1"
destino="$2"

if [ ! -d "$origen" ]; then
    echo "Error: el directorio de origen '$origen' no existe."
    exit 1
fi

if [ ! -d "$destino" ]; then
    echo "Error: el directorio de destino '$destino' no existe."
    exit 1
fi

fecha=$(date +"%Y%m%d")
nombre_dir=$(basename "$origen" | tr -d '/')
nombre_backup="${nombre_dir}_bkp_${fecha}.tar.gz"
ruta_backup="$destino/$nombre_backup"

tar -czf "$ruta_backup" "$origen"

if [ $? -eq 0 ]; then
    echo "Backup exitoso: $ruta_backup"
else
    echo "Hubo un error al crear el backup."
    fecha_hora=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$fecha_hora] Error al generar backup de $origen" >> "$destino/log.txt"
    exit 1
fi

